// Definición del módulo AngularJS
var app = angular.module('crudApp', []);

// Definición del controlador
app.controller('MainController', ['$scope', '$http', function($scope, $http) {
    
    // Inicializar listas y variables
    $scope.categories = []; // Lista de categorías
    $scope.categoryName = '';
    $scope.productCode = '';
    $scope.productName = '';
    $scope.selectedCategory = '';
    $scope.productPrice = '';

}]);
