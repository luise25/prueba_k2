<?php
// Incluir el archivo de conexión
require_once("conexion.php");

// Incluir el archivo de funciones
require_once("funciones.php");

// Verificar si se ha recibido un ID a través de la URL
if (isset($_GET['id'])) {
    // Obtener el ID del producto
    $id_producto = $_GET['id'];

    // Llamar a la función eliminar
    eliminar($id_producto);

    // Redirigir al usuario a la página de listado después de eliminar
    header("Location: listar.php");
    exit();
} else {
    echo "ID de producto no proporcionado.";
}
?>