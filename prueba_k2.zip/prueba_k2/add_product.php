<?php
// Incluir el archivo de conexión
require_once("conexion.php");

// Obtener los datos enviados en la solicitud POST
$data = json_decode(file_get_contents("php://input"), true);

// Verificar si los datos necesarios están presentes
if (isset($data['code']) && isset($data['prod_name']) && isset($data['category_id']) && isset($data['price'])) {
    $code = $data['code'];
    $prod_name = $data['prod_name'];
    $category_id = $data['category_id'];
    $price = $data['price'];

    // Insertar el producto
    insertar_producto($code, $prod_name, $category_id, $price);
} else {
    // Enviar respuesta JSON con un error si faltan datos
    echo json_encode(array("message" => "Faltan datos para añadir el producto."));
}

function insertar_producto($code, $prod_name, $category_id, $price) {
    global $conexion;

    // Verificar si alguno de los campos está vacío
    if (empty($code) || empty($prod_name) || empty($category_id) || empty($price)) {
        die(json_encode(array("message" => "Todos los campos son obligatorios.")));
    }

    // Preparar la consulta SQL para insertar en la tabla Product
    $sql_prod = $conexion->prepare("INSERT INTO Product (code, name, category_id, price, createdAt, updatedAt) VALUES (?, ?, ?, ?, NOW(), NOW())");

    if ($sql_prod === false) {
        die(json_encode(array("message" => "Error al preparar la consulta para Product: " . $conexion->error)));
    }

    $sql_prod->bind_param("ssid", $code, $prod_name, $category_id, $price);

    // Ejecutar la consulta para Product
    if ($sql_prod->execute()) {
        // Enviar respuesta JSON en caso de éxito
        echo json_encode(array("message" => "Producto añadido exitosamente."));
    } else {
        // Enviar respuesta JSON con el error
        echo json_encode(array("message" => "Error al insertar producto: " . $sql_prod->error));
    }

    $sql_prod->close();
}
?>
