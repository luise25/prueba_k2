<?php

function listar() {
    global $conexion;

    $sql = "SELECT * FROM Category";
    $sql2 = "SELECT * FROM Product";

    $resultado = mysqli_query($conexion, $sql);
    $resultado2 = mysqli_query($conexion, $sql2);

    // Verifica que ambas consultas se ejecutaron correctamente
    if (!$resultado) {
        die("Fallo en la ejecución de la consulta de Categorías: " . mysqli_error($conexion));
    }

    if (!$resultado2) {
        die("Fallo en la ejecución de la consulta de Productos: " . mysqli_error($conexion));
    }

    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>Categoría</th>";
    echo "<th>Producto</th>";
    echo "</tr>";
    echo "<tr>";
    echo "<td valign='top'>";  // Columna de Categoría

    // Mostrar resultados de Category
    while ($fila = mysqli_fetch_assoc($resultado)) {
        echo "ID: " . $fila["id"] . "<br>";
        echo "Nombre: " . $fila["name"] . "<br>";
        echo "Fecha de Creación: " . $fila["createdAt"] . "<br>";
        echo "Fecha de Actualización: " . $fila["updatedAt"] . "<br><br><br>";
    }

    echo "</td>";
    echo "<td valign='top'>";  // Columna de Producto

    // Mostrar resultados de Product
    while ($fila2 = mysqli_fetch_assoc($resultado2)) {
        echo "Código: " . $fila2["code"] . "<br>";
        echo "Nombre: " . $fila2["name"] . "<br>";
        echo "ID Categoría: " . $fila2["category_id"] . "<br>";
        echo "Precio: " . $fila2["price"] . "<br><br><br>";
    }

    echo "</td>";
    echo "</tr>";
    echo "</table>";
}



function insertar($code,$prod_name,$category,$price) {
    global $conexion;

    if (empty($code) || empty($prod_name) || empty($category) || empty($price)) {
        die("Los campos están vacíos");
    }

    // Preparar la consulta SQL para insertar en la tabla Category
    $sql_cat = $conexion->prepare("INSERT INTO Category (name) VALUES (?)");

    if ($sql_cat === false) {
        die("Error al preparar la consulta para Category: " . $conexion->error);
    }
    $sql_cat->bind_param("s", $cat_nombre);

    // Ejecutar la consulta para Category
    if ($sql_cat->execute()) {
        echo "Categoría insertada correctamente.";
    } else {
        echo "Error al insertar categoría: " . $sql_cat->error;
    }
//
    //// Obtener el ID de la categoría insertada
    //$category_id = $conexion->insert_id;

    // Ahora en la tabla Product
    $sql_prod = $conexion->prepare("INSERT INTO Product (code, name, category_id, price) VALUES (?, ?, ?, ?)");

    if ($sql_prod === false) {
        die("Error al preparar la consulta para Product: " . $conexion->error);
    }
    $sql_prod->bind_param("ssid", $code, $prod_name, $category, $price);

    if ($sql_prod->execute()) {
        echo "Producto insertado correctamente.";
    } else {
        echo "Error al insertar producto: " . $sql_prod->error;
    }

    // Cerrar conexión
    $sql_cat->close();
    $sql_prod->close();
}

function categoria_existe($nombre_categoria) {
    global $conexion;

    // Preparar la consulta para verificar si la categoría existe
    $sql = $conexion->prepare("SELECT COUNT(*) FROM Category WHERE name = ?");
    if ($sql === false) {
        die("Error al preparar la consulta: " . $conexion->error);
    }

    $sql->bind_param("s", $nombre_categoria);
    $sql->execute();
    $sql->bind_result($count);
    $sql->fetch();
    $sql->close();

    return $count > 0; // Devuelve true si la categoría existe, false si no
}

function insertar_categoria($cat_nombre) {
    global $conexion;

    // Verificar si la categoría ya existe
    if (categoria_existe($cat_nombre)) {
        die("La categoría '$cat_nombre' ya existe.");
    }

    // Preparar la consulta SQL para insertar en la tabla Category
    $sql_cat = $conexion->prepare("INSERT INTO Category (name, createdAt, updatedAt) VALUES (?, NOW(), NOW())");

    if ($sql_cat === false) {
        die("Error al preparar la consulta para Category: " . $conexion->error);
    }
    $sql_cat->bind_param("s", $cat_nombre);

    // Ejecutar la consulta para Category
    if ($sql_cat->execute()) {
        echo "Categoría insertada correctamente.<br>";
    } else {
        echo "Error al insertar categoría: " . $sql_cat->error . "<br>";
    }

    $sql_cat->close();
}

function insertar_producto($code, $prod_name, $category_id, $price) {
    global $conexion;

    if (empty($code) || empty($prod_name) || empty($category_id) || empty($price)) {
        die("Los campos están vacíos");
    }

    // Preparar la consulta SQL para insertar en la tabla Product
    $sql_prod = $conexion->prepare("INSERT INTO Product (code, name, category_id, price, createdAt, updatedAt) VALUES (?, ?, ?, ?, NOW(), NOW())");

    if ($sql_prod === false) {
        die("Error al preparar la consulta para Product: " . $conexion->error);
    }
    $sql_prod->bind_param("ssid", $code, $prod_name, $category_id, $price);

    // Ejecutar la consulta para Product
    if ($sql_prod->execute()) {
        echo "Producto insertado correctamente.";
    } else {
        echo "Error al insertar producto: " . $sql_prod->error;
    }

    $sql_prod->close();
}

function listar_id_categoria() {
    global $conexion;
    $sql = "SELECT id, name FROM Category";
    $resultado = mysqli_query($conexion, $sql);

    if (!$resultado) {
        die("Fallo en la ejecución de la consulta de Categorías: " . mysqli_error($conexion));
    }

    // Mostrar las opciones de categoría en un select
    while ($fila = mysqli_fetch_assoc($resultado)) {
        echo '<option value="' . $fila["id"] . '">' . $fila["name"] . '</option>';
    }
}


function editar($id, $code, $prod_name, $category, $price) {
    global $conexion;
    
    $sql = $conexion->prepare("UPDATE Product SET code=?, name=?, category_id=?, price=?, updatedAt=NOW() WHERE id=?");
    if ($sql === false) {
        die("Error al preparar la consulta: " . $conexion->error);
    }
    
    $sql->bind_param("ssidi", $code, $prod_name, $category, $price, $id);
    
    if ($sql->execute()) {
        echo "Producto actualizado correctamente.";
    } else {
        echo "Error al actualizar el producto: " . $sql->error;
    }
    
    $sql->close();
}

function eliminar($id) {
    global $conexion;
    
    $sql = $conexion->prepare("DELETE FROM Product WHERE id=?");
    if ($sql === false) {
        die("Error al preparar la consulta: " . $conexion->error);
    }
    
    $sql->bind_param("i", $id);
    
    if ($sql->execute()) {
        echo "Producto eliminado correctamente.";
    } else {
        echo "Error al eliminar el producto: " . $sql->error;
    }
    
    $sql->close();
}

?>