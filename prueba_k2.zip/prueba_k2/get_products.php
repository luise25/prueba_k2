<?php
// Incluir el archivo de conexión
require_once("conexion.php");

// Incluir el archivo de funciones
require_once("funciones.php");


// Realizar la consulta a la base de datos para obtener los productos
$sql = "SELECT * FROM Product";
$resultado = mysqli_query($conexion, $sql);

// Verificar si la consulta fue exitosa
if (!$resultado) {
    die("Fallo en la ejecución de la consulta de Productos: " . mysqli_error($conexion));
}

// Obtener los productos en un array
$productos = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $productos[] = $row;
}

// Enviar el array como JSON
header('Content-Type: application/json');
echo json_encode($productos);
?>
