<?php
// Incluir el archivo de conexión
require_once("conexion.php");

// Incluir el archivo de funciones
require_once("funciones.php");

// Obtener los datos enviados en la solicitud POST
$data = json_decode(file_get_contents("php://input"), true);

// Verificar si los datos necesarios están presentes
if (isset($data['code']) && isset($data['name']) && isset($data['category_id']) && isset($data['price'])) {
    $id = $data['id'];
    $code = $data['code'];
    $prod_name = $data['name'];
    $category_id = $data['category_id'];
    $price = $data['price'];

    if ($id != null){
        // Actualizar el producto
        editar($id, $code, $prod_name, $category_id, $price);   
    } else {
        insertar($code, $prod_name, $category_id, $price);
    }

    // Enviar respuesta JSON
    echo json_encode(array("message" => "Producto actualizado exitosamente."));
} else {
    echo json_encode(array("message" => "Faltan datos para actualizar el producto."));
}
?>
