<?php
// Incluir el archivo de conexión
require_once("conexion.php");

// Incluir el archivo de funciones
require_once("funciones.php");

// Obtener los datos enviados por POST
$data = json_decode(file_get_contents('php://input'), true);

$cat_nombre = $data['cat_nombre'];

// Verificar si el campo está vacío
if (empty($cat_nombre)) {
    echo json_encode(array('message' => 'El nombre de la categoría no puede estar vacío.'));
    exit();
}

// Llamar a la función para insertar categoría
insertar_categoria($cat_nombre);

// Enviar respuesta al cliente
echo json_encode(array('message' => 'Categoría agregada correctamente.'));
?>
