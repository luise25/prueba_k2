<?php
// Detalles de la conexión
$servername = "localhost";
$username = "root";
$password = "246902";
$dbname = "base_datos_prueba_k2";

// Crear la conexión
$conexion = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}
?>