<!DOCTYPE html>
<html lang="en" ng-app="crudApp">
<head>
    <meta charset="UTF-8">
    <title>Listar Productos</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- AngularJS -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <!-- Archivo de AngularJS -->
    <script src="js/app.js"></script>
</head>
<body ng-controller="ListController">
    <div class="container mt-4">
        <h2>Listado de Productos</h2>
        
        <!-- Botones para Nuevo Producto y Nueva Categoría -->
        <div class="mb-3">
            <button class="btn btn-primary" ng-click="newProduct()">Nuevo Producto</button>
            <button class="btn btn-secondary ml-2" ng-click="newCategory()">Nueva Categoría</button>
        </div>
        
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="product in products">
                    <td>{{product.code}}</td>
                    <td>{{product.name}}</td>
                    <td>{{product.price}}</td>
                    <td>
                        <button class="btn btn-warning" ng-click="editProduct(product.id)">Editar</button>
                        <button class="btn btn-danger" ng-click="deleteProduct(product.id)">Eliminar</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- AngularJS Script -->
    <script>
        var app = angular.module('crudApp', []);
        
        app.controller('ListController', ['$scope', '$http', function($scope, $http) {
            $scope.products = [];

            // Obtener productos del servidor
            function getProducts() {
                $http.get('get_products.php').then(function(response) {
                    $scope.products = response.data;
                }).catch(function(error) {
                    console.error('Error al obtener los productos:', error);
                });
            }

            getProducts();

            // Eliminar un producto
            $scope.deleteProduct = function(productId) {
                if (confirm('¿Estás seguro de que deseas eliminar este producto?')) {
                    $http.get('eliminar.php?id=' + productId).then(function(response) {
                        alert('Eliminado con exito');
                        getProducts(); // Recargar la lista de productos después de la eliminación
                    }).catch(function(error) {
                        console.error('Error al eliminar el producto:', error);
                    });
                }
            };

            // Editar un producto (redireccionar a la página de edición)
            $scope.editProduct = function(productId) {
                // Redirigir a la página de edición con el ID del producto
                window.location.href = 'editar.php?id=' + productId;
            };

            // Redirigir para crear un nuevo producto
            $scope.newProduct = function() {
                window.location.href = 'editar.php';
            };

            // Redirigir a la página de index.php para crear una nueva categoría
            $scope.newCategory = function() {
                window.location.href = 'index.php';
            };
        }]);
    </script>
</body>
</html>
