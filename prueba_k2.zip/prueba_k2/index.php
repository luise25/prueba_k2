<!DOCTYPE html>
<html lang="es" ng-app="crudApp">
<head>
    <meta charset="UTF-8">
    <title>CRUD de Productos</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- AngularJS -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <!-- Archivo de AngularJS -->
    <script src="js/app.js"></script>
</head>
<body ng-controller="MainController">
    <div class="container">
        <h2 class="mt-4">CRUD de Productos</h2>

        <!-- Formulario para agregar una categoría -->
        <form name="categoriaForm" ng-submit="addCategory()" class="mt-4">
            <h3>Categoría producto</h3>
            <div class="form-group">
                <input type="text" class="form-control" ng-model="categoryName" placeholder="Categoría" required>
            </div>
            <button type="submit" class="btn btn-primary">Agregar Categoría</button>
        </form>
    </div>

    <!-- AngularJS Script -->
    <script>
        var app = angular.module('crudApp', []);
        
        app.controller('MainController', ['$scope', '$http', function($scope, $http) {
            $scope.categories = [];

            // Fetch categories from the server
            function getCategories() {
                $http.get('get_categories.php').then(function(response) {
                    $scope.categories = response.data;
                }).catch(function(error) {
                    console.error('Error al obtener las categorías:', error);
                });
            }

            // Call getCategories on controller initialization
            getCategories();

            // Add new category
            $scope.addCategory = function() {
                var data = { cat_nombre: $scope.categoryName };
                $http.post('add_category.php', data).then(function(response) {
                    alert(response.data.message);
                    $scope.categoryName = '';
                    getCategories(); // Refresh category list
                }).catch(function(error) {
                    console.error('Error al agregar la categoría:', error);
                });
            };
        }]);
    </script>
</body>
</html>
