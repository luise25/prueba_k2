<?php
// Incluir el archivo de conexión
require_once("conexion.php");

// Realizar la consulta a la base de datos para obtener las categorías
$sql = "SELECT * FROM Category";
$resultado = mysqli_query($conexion, $sql);

// Verificar si la consulta fue exitosa
if (!$resultado) {
    die("Fallo en la ejecución de la consulta de Categorías: " . mysqli_error($conexion));
}

// Obtener las categorías en un array
$categorias = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $categorias[] = $row;
}

// Enviar el array como JSON
header('Content-Type: application/json');
echo json_encode($categorias);
?>

