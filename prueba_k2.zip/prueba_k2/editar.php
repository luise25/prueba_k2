<!DOCTYPE html>
<html lang="en" ng-app="crudApp">
<head>
    <meta charset="UTF-8">
    <title>Editar Producto</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- AngularJS -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <!-- Archivo de AngularJS -->
    <script src="js/app.js"></script>
</head>
<body ng-controller="EditController">
    <div class="container">
        <h2 class="mt-4">{{pageTitle}}</h2>
        
        <form name="editForm" ng-submit="updateProduct()" class="mt-4">
            <input type="hidden" ng-model="product.id">
            <div class="form-group">
                <label>Código:</label>
                <input type="text" class="form-control" ng-model="product.code" required>
            </div>
            <div class="form-group">
                <label>Nombre del producto:</label>
                <input type="text" class="form-control" ng-model="product.name" required>
            </div>
            <div class="form-group">
                <label>Categoría:</label>
                <select ng-model="product.category_id" class="form-control" required>
                    <option value="">Seleccionar Categoría</option>
                    <option ng-repeat="cat in categories" value="{{cat.id}}">{{cat.name}}</option>
                </select>
            </div>
            <div class="form-group">
                <label>Precio:</label>
                <input type="text" class="form-control" ng-model="product.price" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar cambios</button>
        </form>
    </div>

    <!-- AngularJS Script -->
    <script>
        function getParameterByName(name) {
            // Crear un patrón para buscar el parámetro en la URL
            name = name.replace(/[\[\]]/g, '\\$&');
            var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                results = regex.exec(window.location.href);

            // Si el parámetro no está en la URL, retornar null
            if (!results) return null;
            // Si no hay valor después del igual, retornar cadena vacía
            if (!results[2]) return '';
            // Decodificar el valor del parámetro y retornarlo
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
        }

        var app = angular.module('crudApp', []);
        
        app.controller('EditController', ['$scope', '$http', function($scope, $http) {
            $scope.categories = []; // List of categories
            $scope.idProducto = -1; // List of categories
            $scope.EsNuevoBool = true;
            $scope.product = {};
            $scope.pageTitle = '';
            
            // Initialize product data
            function init() {
                $scope.idProducto = getParameterByName('id');
                $scope.EsNuevoBool = !($scope.idProducto && $scope.idProducto != 0);
                $scope.pageTitle = $scope.EsNuevoBool ? 'Nuevo Producto' : 'Editar producto';
                
                // Fetch categories from the server
                $http.get('get_categories.php').then(function(response) {
                    $scope.categories = response.data;
                });
                
                //$scope.product = product;
                if ($scope.EsNuevoBool == false) {
                 //$http.get('get_product_by_id.php?id=' + $scope.idProducto).then(function(response) {
                 $http.get('get_products.php').then(function(response) {
                     
                     if (!response.data)  {
                         return;
                     } else {
                         var pro = response.data.find(x => x.id == $scope.idProducto);
                         if (pro) {
                          $scope.product = pro;
                         } else{
                             alert('Producto no encontrado');
                         }
                     }
                    }).catch(function(error) {
                        console.error('Error al obtener el producto con id : ' + $scope.idProducto, error);
                    });
                }
            };

            // Function to update product
            $scope.updateProduct = function() {
                $http.post('update_product.php', $scope.product).then(function(response) {
                    alert('Producto confirmado');
                });
            };
            // Función para agregar un nuevo producto
            $scope.addProduct = function() {
                var data = {
                    code: $scope.productCode,
                    prod_name: $scope.productName,
                    category: $scope.selectedCategory,
                    price: $scope.productPrice
                };

                $http.post('add_product.php', data).then(function(response) {
                    alert(response.data.message);
                    $scope.productCode = '';
                    $scope.productName = '';
                    $scope.selectedCategory = '';
                    $scope.productPrice = '';
                }).catch(function(error) {
                    console.error('Error al agregar el producto:', error);
                });
            };
            // Función para agregar categoría
            $scope.addCategory = function() {
                var data = { cat_nombre: $scope.categoryName };
                $http.post('add_category.php', data).then(function(response) {
                    if (response.data && response.data.message) {
                        alert(response.data.message); // Mensaje desde el servidor
                    } else {
                        alert('Respuesta inesperada del servidor.');
                    }
                    $scope.categoryName = ''; // Limpiar campo
                }).catch(function(error) {
                    alert('Error al agregar la categoría.'); // Mensaje en caso de error
                    console.error('Error al agregar la categoría:', error);
                });
            };
            
            init();
        }]);
    </script>
</body>
</html>
